<?php
	session_start();
	if ($_SESSION['login'] == null)
	{
		header("Location: admin.php");
		exit;
	}
	if (!isset($_COOKIE['admin'])) {
	   setcookie('admin', 'false');
	   $_COOKIE['admin'] = 'false';
	   echo '
<html>
<head><title>404 Not Found</title></head>
<body bgcolor="white">
<center><h1>404 Not Found</h1></center>
<center><p><a href="https://35.211.66.169/">Did you find your voter registration status on this page?</a></p></center>
<hr><center>nginx/1.14.0</center>
</body>
</html>
<!-- Hmmm, the plot thickens... key{9ffbb4e2db417c890e19f69480c4abce9d422bb442224eff8cfa48d23e56e033}-->';
     }
     elseif (isset($_COOKIE['admin']) && strcmp($_COOKIE['admin'], 'true') == 0) {
     	    echo "<!DOCTYPE html><html><head><title>Main</title></head><body><p>Congratulations! Here you go: key{58cd4449f2dd59fa8231b1c64249fe32cb7628b374a4c4999969654829394012}</p></body></html>";
     }
     else {
                echo '
<html>
<head><title>404 Not Found</title></head>
<body bgcolor="white">
<center><h1>404 Not Found</h1></center>
<center><p><a href="https://35.211.66.169/">Did you find your voter registration status on this page?</a></p></center>
<hr><center>nginx/1.14.0</center>
</body>
</html>
<!-- Hmmm, the plot thickens... key{9ffbb4e2db417c890e19f69480c4abce9d422bb442224eff8cfa48d23e56e033}-->';}
?>
